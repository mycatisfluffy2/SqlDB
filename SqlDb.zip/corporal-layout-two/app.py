from flask import Flask, render_template, request, redirect
import sqlite3

app = Flask(__name__)

@app.route('/',methods=['GET','POST'])
def home():
    connect = sqlite3.connect('database.db')
    connect.execute('''CREATE TABLE IF NOT EXISTS PARTICIPANTS (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                city TEXT NOT NULL,
                country TEXT NOT NULL
    );''')
    connect.close()

    if request.method == "POST":
        name = request.form.get('name')
        city = request.form.get('city')
        country = request.form.get('country')

        # Validate that all fields are provided
        if name and city and country:
            with sqlite3.connect("database.db") as users:
                cursor = users.cursor()
                cursor.execute("INSERT INTO PARTICIPANTS (name, city, country) VALUES (?, ?, ?)", (name, city, country))
                users.commit()
            return redirect('/')
        else:
            error = "All fields are required!"
            return render_template("index.html", error=error)
    else:
        connect = sqlite3.connect('database.db')
        cursor = connect.cursor()
        cursor.execute('SELECT * FROM PARTICIPANTS')
        data = cursor.fetchall()
        return render_template("index.html", data=data)

if __name__ == '__main__':
    app.run(debug=True)
















    # Server/db 

    # Data  

    # function() {
    #     get data
    #     add data to array
    # }

    # array[stuff]


    # table for each stuff

